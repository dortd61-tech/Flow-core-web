FLOW SMP – webový návrh

1. Rozbal ZIP.
2. Otevři složku flow_smp_web.
3. Dvakrát klikni na index.html – otevře se v prohlížeči.

Poznámka: Staff panel je zatím jen grafický návrh. Přihlášení není napojené na zabezpečený server a změny se neukládají.
